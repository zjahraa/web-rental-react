import React from 'react';
// import '/Footer.css'; 
import '../styling/Footer.css'
function Footer() {
  return (
    <footer>
      <div className="footer-content">
        <div className="footer-info">
          <p>Alamat: Jl. Contoh No. 123, Kota Contoh</p>
          <p>Email: info@contohrentalmobil.com</p>
          <p>Telepon: (123) 456-7890</p>
        </div>
      </div>
      <div className="footer-bottom">
        &copy; {new Date().getFullYear()} Contoh Rental Mobil. Hak Cipta Dilindungi.
      </div>
    </footer>
  );
}

export default Footer;
