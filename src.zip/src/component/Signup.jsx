import React, { useState } from 'react';
// import { createUserWithEmailAndPassword } from "firebase/auth";
import { UserAuth } from '../context/AuthContext';

// import { useHistory } from 'react-router-dom';

function SignUp() {
    const { createUser } = UserAuth();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [displayName, setDisplayName] = useState('');
  const [photoURL, setPhotoURL] = useState('');
  const [phoneNumber, setPhoneNumber] = useState('');
//   const history = useHistory();



  const handleSignUp = async (e) => {
    e.preventDefault();
    try {
      await createUser(email, password, displayName, photoURL, phoneNumber);
    } catch (error) {
      console.error('Error signing up:', error);
    }
  };


  return (
    <div>
      <h2>Sign Up</h2>
      <form onSubmit={handleSignUp}>
        <div>
          <label>Nama</label>
          <input type="text" value={displayName} onChange={(e) => setDisplayName(e.target.value)} />
        </div>
        
        <div>
          <label>No Telp.</label>
          <input type="text" value={phoneNumber} onChange={(e) => setPhoneNumber(e.target.value)} />
        </div>
        <div>
          <label>Alamat Email</label>
          <input type="email" value={email} onChange={(e) => setEmail(e.target.value)} />
        </div>
        <div>
          <label>Kata Sandi</label>
          <input type="password" value={password} onChange={(e) => setPassword(e.target.value)} />
        </div>
        <div>
          <label>URL Foto Profil</label>
          <input type="text" value={photoURL} onChange={(e) => setPhotoURL(e.target.value)} />
        </div>
        <button type="submit">Daftar</button>
      </form>
    </div>
  );
}

export default SignUp;