import React, { Component } from 'react';
// import { defineAsyncComponent, effect } from 'vue';

class Register extends Component{
    render(){
        return(
            <div>
                <p>Login Page</p>
                <button>Go To Register</button>
                <button>Go To Dashboard</button>
            </div>
        )
    }
}
export default Register;